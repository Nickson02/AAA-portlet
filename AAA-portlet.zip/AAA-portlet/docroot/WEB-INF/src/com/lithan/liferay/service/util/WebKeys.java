package com.lithan.liferay.service.util;

public class WebKeys implements com.liferay.portal.kernel.util.WebKeys{
	public static final String SERVIC = "SERVIC";
	public static final String SERVIC_CUSTOMER = "SERVIC_CUSTOMER";
}
